gcc -o sendrawpacket sendrawpacket.c -g ./libpcap.a
#./sendrawpacket eth1
